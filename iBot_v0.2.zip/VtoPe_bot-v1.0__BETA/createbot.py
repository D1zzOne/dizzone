from time import sleep
import requests
import json
from random import choice
from string import ascii_letters
from colorama import Fore, Back, Style
from colorama import init

init(autoreset=True)

utoken = input('Введите utoken (вы можете найти его на странице настроек ' + Fore.YELLOW + 'https://vto.pe/app/#/settings): ')
bot_name = input(Fore.YELLOW + 'Введите имя бота (не более 10 символов): ')

device = (''.join(choice(ascii_letters) for i in range(60)))
prefix = (''.join(choice(ascii_letters) for i in range(4)))

r = requests.get('https://vto.pe/botapi/user?utoken=' + utoken + '&device=' + device + '&program=' + prefix + '&bot=' + bot_name)
r_arr = r.json()
if r_arr["btoken"] != '' :
    print ('Успешно! Ваш btoken: ' + Fore.GREEN + r_arr["btoken"])