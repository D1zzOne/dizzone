from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options as ChromeOptions
import requests
import json
import hashlib
import time
from time import sleep
import urllib.request
from colorama import Fore, Back, Style
from colorama import init
import pyvirtualdisplay

#display = pyvirtualdisplay.Display(visible=True, size=(800, 600))
#display.start()

init(autoreset=True)

usrname = input('Введите логин от аккаунта Instagram: ')
try:
    r = requests.get('https://www.instagram.com/' + usrname +'/')
    r_id_content = r.content
    r_id = str(r_id_content).split('profilePage_')[1]
    acc_id = str(r_id).split('"')[0]
    print(acc_id)
except:
    acc_id = input('Введите id аккаунта: ')

passwd = input('Введите пароль от аккаунта Instagram: ')

btoken = input('Введите ваш btoken (он выдается каждому боту, если вы создавали его файлом createbot.py): ')
timeout_input = input('Введите сколько будет длиться перерыв, между выполнением заданий: ')
loop_subs = input('Введите количество подписок за цикл: ')
loop_delay = input('Введите перерыв(в секундах): ')
use_proxy = input('Будете ли вы использовать прокси? (y - да ; n - нет): ')
if use_proxy == 'n':
    use_vpn = input('Будете ли вы использовать бесплатный VPN Германия (Windscribe VPN)? (y - да ; n - нет): ')
if use_vpn == 'y':
    vpn_usrname = input('Введите имя пользователя Windscribe: ')
    vpn_passwd = input('Введите пароль Windscribe: ')

# selenium_url = "http://localhost:4444/wd/hub"
# caps = {
#     "browserName": "chrome",
#     "browserVersion": "85.0",
#         "selenoid:options": {
#         "enableVNC": True,
#         "enableVideo": False
#         }
#     }
chrome_options = ChromeOptions()
if use_vpn == 'y':
    
    chrome_options.add_extension('D:/Program Files (x86)/Programming/Python/Projects/VtoPe_bot-v1.0__BETA/langswitch.crx')
    chrome_options.add_extension('D:/Program Files (x86)/Programming/Python/Projects/VtoPe_bot-v1.0__BETA/foxyproxy.crx')
if use_proxy == 'y':
    proxy_host = input('Введите адрес прокси: ')
    proxy_port = input('Введите адрес порт: ')
    proxy_usr = input('Введите имя пользователя(если есть, если нет нажмите ENTER): ')
    proxy_pass = input('Введите пароль(если есть, если нет нажмите ENTER): ')
    proxy_type = input('Введите адрес тип прокси(1 - http/https ; 2 - socks4 ; 3 - socks5), ТОЛЬКО цифра!!!: ')
driver = webdriver.Chrome(executable_path='D:/Program Files (x86)/Programming/Python/Projects/1/chromedriver.exe', options=chrome_options)
driver.maximize_window()

# driver.implicitly_wait(3)
# driver.close()
# time.sleep(1)
# driver.switch_to.window(driver.window_handles[1])
# time.sleep(1)
# driver.close()
# time.sleep(1)
# driver.switch_to.window(driver.window_handles[0])

if use_proxy == 'y' :

    driver.get('chrome-extension://gcknhkkoolaabfmlnjonogaaifnjlfnp/options.html')
    sleep(1)
    driver.find_element_by_xpath('/html/body/div[2]/div[2]/table/tbody/tr/td[2]/button[3]').click()
    driver.find_element_by_xpath('/html/body/div[20]/div[2]/div/div[2]/table[2]/tbody/tr[3]/td/input[1]').send_keys(str(proxy_host))
    sleep(1)
    driver.find_element_by_xpath('/html/body/div[20]/div[2]/div/div[2]/table[2]/tbody/tr[3]/td/input[2]').send_keys(str(proxy_port))

    if proxy_type == '3' :
        driver.find_element_by_xpath('/html/body/div[20]/div[2]/div/div[2]/table[2]/tbody/tr[4]/td/input[1]').click()

    if proxy_type == '2' :
        driver.find_element_by_xpath('/html/body/div[20]/div[2]/div/div[2]/table[2]/tbody/tr[4]/td/input[1]').click()
        driver.find_element_by_xpath('/html/body/div[20]/div[2]/div/div[2]/table[2]/tbody/tr[4]/td/input[2]').click()

    driver.find_element_by_xpath('/html/body/div[20]/div[2]/div/div[2]/table[2]/tbody/tr[6]/td[1]/input').click()
    driver.find_element_by_xpath('/html/body/div[21]/div[3]/div/button[1]').click()
    driver.find_element_by_xpath('/html/body/div[19]/div[2]/div/div[2]/table[2]/tbody/tr[6]/td[1]/div/input[1]').send_keys(str(proxy_usr))
    sleep(1)
    driver.find_element_by_xpath('/html/body/div[19]/div[2]/div/div[2]/table[2]/tbody/tr[6]/td[1]/div/input[2]').send_keys(str(proxy_pass))
    sleep(1)
    driver.find_element_by_xpath('/html/body/div[19]/div[2]/div/div[2]/table[2]/tbody/tr[6]/td[1]/div/input[3]').send_keys(str(proxy_pass))
    sleep(1)
    driver.find_element_by_xpath('/html/body/div[19]/div[3]/div/button[1]').click()
    driver.get('chrome-extension://gcknhkkoolaabfmlnjonogaaifnjlfnp/popup.html')
    driver.find_element_by_xpath('/html/body/ul/li[2]').click()
    driver.get('https://2ip.io')
    sleep(1)
    myip = driver.find_element_by_xpath('/html/body/div[1]/div[3]/div[1]/div/div[1]/section[1]/div/div[1]/div/div[1]/span').text
    print('Ваш ip после применения прокси: ', str(myip))
    if myip == proxy_host :
        print('Прокси ' + Fore.GREEN + 'РАБОТАЕТ')
    if str(myip) != str(proxy_host) :
        proxy_err = input(Fore.RED +'ip адрес прокси не совпадает с ip при тесте. Либо проксирование производится на другой ip(прокси работает), либо прокси не работает. Продолжить?(y - да ; n - нет)')    
        if proxy_err == 'n':
            quit

    time.sleep(9)

if use_vpn == 'y':
    driver.get('chrome-extension://hnmpcagpplmpfojmgmnngilcnanddlhb/popup.html')    
    sleep(1)
    driver.get('chrome-extension://hnmpcagpplmpfojmgmnngilcnanddlhb/popup.html') 
    sleep(2)
    driver.find_element_by_xpath('/html/body/div/div/div[3]/div[1]/button[1]').click()
    sleep(1)
    driver.find_element_by_xpath('/html/body/div/div/div/form/div[1]/div[2]/input').send_keys('randlox60')
    sleep(1)
    driver.find_element_by_xpath('/html/body/div/div/div/form/div[2]/div[2]/input').send_keys('asdtyu123')
    sleep(1)
    driver.find_element_by_xpath('/html/body/div/div/div/form/div[3]/button').click()
    sleep(15)
    driver.get('chrome-extension://hnmpcagpplmpfojmgmnngilcnanddlhb/popup.html')
    sleep(1)
    driver.find_element_by_xpath('/html/body/div/div/button[2]').click()
    sleep(3)

    driver.find_element_by_xpath('/html/body/div/div/div[4]/div[1]/div[1]/div[1]/div/div[2]/button').click()
    sleep(1)
    driver.find_element_by_xpath('/html/body/div/div/div[2]/div/div/div[19]/div[1]').click()
    sleep(1)
    driver.find_element_by_xpath('/html/body/div/div/div[2]/div/div/div[19]/div[2]/div[1]').click()
    sleep(1)
    driver.get('chrome-extension://kngfjpghaokedippaapkfihdlmmlafcc/popup/index.html')
    sleep(1)
    driver.find_element_by_xpath('/html/body/div/div/ul/li[1]/button').click()
    sleep(1)
print('Начинаем!')
driver.get('https://instagram.com/accounts/login')
sleep(2)
#driver.find_element_by_xpath('//input[contains(@name, "username")]').send_keys(str(usrname))
try:
    driver.find_element_css_selector('button[class="bIiDR"]').click()
    print('cookie accept')
    sleep(1)
except:
    print('cookie skipped')
driver.find_element_by_css_selector("input[name='username']").send_keys(str(usrname))
driver.find_element_by_css_selector("input[name='password']").send_keys(str(passwd))
driver.find_element_by_css_selector("button[type='submit']").click()
sleep(2)


subscribe = int(loop_subs) # Количество заданий типа "Подписаться".
timeout = int(timeout_input) # Перерыв между выполнением заданий.
subscribe2 = 0 # Subscribe2 используется в цикле, после прохождение цикла while (т. е. подписки на аккаунт), увеличивается на 1. Не изменять (без понимания работы скрипта).
sleep(1)

r = requests.get('https://vto.pe/botapi/i/account?btoken='+ str(btoken) +'&id=' + str(acc_id) + '&nick=' + str(usrname))
r_arr = r.json()
print("Atoken для аккаунта: " + Fore.YELLOW + str(r_arr["atoken"]))
sleep(10)

loop_const = 1

while loop_const == 1:
    while subscribe2<subscribe :
        r2 = requests.get('https://tasks.vto.pe/botapi/tasks/i/follow?atoken=' + str(r_arr["atoken"]))
        r_arr2 = r2.json()
        try:
            print("Task id: ", r_arr2["id"], "; Нужно подписаться на: ", r_arr2["shortcode"])
            sleep(1)
            driver.get('https://instagram.com/' + str(r_arr2["shortcode"]) + '/?hl=en')
            sleep(2)
            driver.find_element_by_xpath('//button[contains(text(), "Follow")]').click()
            sleep(5)
            r3 = requests.get('https://tasks.vto.pe/botapi/tasks/i/done/ok?atoken='+ str(r_arr["atoken"]) +'&id=' + str(r_arr2["id"]))
            r3_arr = r3.json()
            print("Результат (если ok, то всё хорошо): ",r3_arr["error"])

            subscribe2 = subscribe2+1
            print("Циклов пройдено: ", subscribe2)
            sleep(timeout)
        except:
            sleep(16)
            
    sleep(int(loop_delay))
    subscribe2 = 0
print(Fore.GREEN + 'Задача успешно выполнена!')
display.stop()