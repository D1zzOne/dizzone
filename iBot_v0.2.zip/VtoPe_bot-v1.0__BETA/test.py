from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options as ChromeOptions
import requests
import json
import time
from time import sleep

r = requests.get('https://www.instagram.com/innamarss/')
r_id_content = r.content
r_id = str(r_arr).split('profilePage_')[1]
acc_id = str(r_id).split('"')[0]
print(id)