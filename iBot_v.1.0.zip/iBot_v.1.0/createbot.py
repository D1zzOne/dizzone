from time import sleep
import requests
import json
from random import choice
from string import ascii_letters

utoken = input('Введите utoken (вы можете найти его на странице настроек https://vto.pe/app/#/settings): ')
bot_name = input('Введите имя бота (не более 10 символов): ')

device = (''.join(choice(ascii_letters) for i in range(60)))
prefix = (''.join(choice(ascii_letters) for i in range(4)))

r = requests.get('https://vto.pe/botapi/user?utoken=' + utoken + '&device=' + device + '&program=' + prefix + '&bot=' + bot_name)
r_arr = r.json()
if r_arr["btoken"] != '' :
    print ('Успешно! Ваш btoken: ' + r_arr["btoken"])
print(r_arr)