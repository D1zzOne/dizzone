from seleniumwire import webdriver
from time import sleep
import pickle
import requests
import json

options = webdriver.ChromeOptions()
#options.add_argument('--blink-settings=imagesEnabled=false')
driver = webdriver.Chrome(executable_path='D:/Program Files (x86)/Programming/Python/Projects/iBot_v.1.0/chromedriver.exe', options=options)
driver.get('https://instagram.com/benrecy_5')
sleep(600)