from seleniumwire import webdriver
from time import sleep
import pickle
import requests
import json
import random

use_proxy = input('Вы будете использовать прокси? (y - да ; n - нет): ')
if use_proxy == 'y':
    proxy_creditials = input('пользователь:пароль:хост(ip):порт от прокси. Если нет пользователя и пароля, то поставьте там n . Пример - n:n:192.168.0.1:8080  - ')
    split_pc = proxy_creditials.split(':')
    login = split_pc[0]
    password = split_pc[1]
    host = split_pc[2]
    port = split_pc[3]

creditials_1 = input('логин:пароль:id 1-го аккаунта - ')
creditials_2 = input('логин:пароль:id 2-го аккаунта - ')
creditials_3 = input('логин:пароль:id 3-го аккаунта - ')
useragent = input('Mobile Instagram useragent: ')
btoken = input('Ваш btoken: ')
split_c_1 = creditials_1.split(':')
split_c_2 = creditials_2.split(':')
split_c_3 = creditials_3.split(':')

i_usr = split_c_1[0]
i_pass = split_c_1[1]
i_id = split_c_1[2]
i_usr_2 = split_c_2[0]
i_pass_2 = split_c_2[1]
i_id_2 = split_c_2[2]
i_usr_3 = split_c_3[0]
i_pass_3 = split_c_3[1]
i_id_3 = split_c_3[2]

get_task_wait = 'n'

def get_atoken(i_username, i_id, btoken):
    r = requests.get('https://vto.pe/botapi/i/account?btoken='+ str(btoken) +'&id=' + str(i_id) + '&nick=' + str(i_username))
    try:    
        r_arr = r.json()
        global atoken
        atoken = r_arr["atoken"]
    except Exception as ex:
        print(ex)
        print(r.content)

def i_login(i_username, i_password):
    driver.get('https://instagram.com')
    sleep(4)
    try:
        driver.find_element_css_selector('button[class="bIiDR"]').click()
        print('cookie accepted')
        sleep(1)
    except:
        print('cookie skipped')
    try:
        driver.find_element_by_xpath('/html/body/div[2]/div/div/div/div[2]/button[1]').click()
        print('cookie 2 accepted')
        sleep(2)
    except:
        print('cookie 2 skipped')
    sleep(2)
    try:
        driver.find_element_by_xpath('//*[@id="react-root"]/section/main/article/div/div/div/div[2]/button').click()
    except:
        driver.get('https://www.instagram.com/accounts/login/')
        sleep(2)
    sleep(1)
    driver.find_element_by_css_selector("input[name='username']").send_keys(str(i_username))
    driver.find_element_by_css_selector("input[name='password']").send_keys(str(i_password))
    sleep(0.5)
    driver.find_element_by_css_selector("button[type='submit']").click()
    sleep(10)
    driver.get('https://instagram.com')
    sleep(3)
    get_cookie()  

def like_post(i_shortcode):
    sleep(0.1)
    driver.get('https://google.com')
    sleep(0.5)
    driver.get('https://instagram.com/p/'+ str(i_shortcode))
    sleep(3)
    like = driver.find_element_by_xpath('//*[@class="fr66n"]/button')
    like.click()
    sleep(2)

def follow(i_shortcode):
    sleep(0.1)
    driver.get('https://google.com/')
    sleep(0.5)
    driver.get('https://instagram.com/' + str(i_shortcode))
    sleep(3)
    try:
        driver.find_element_by_class_name("_6VtSN").click()
    except:
        print('Follow err 1')
        try:
            driver.find_element_by_xpath('//button[contains(text(), "Follow")]').click()
        except:
            print('Follow err 2')
    sleep(3)
    driver.get('https://instagram.com')

#vtope
def get_follow_task(v_atoken):
    print('Запрашиваем задание...')
    r2 = requests.get('https://tasks.vto.pe/botapi/tasks/i/follow?atoken=' + str(v_atoken))
    r_arr2 = r2.json()
    global task_shortcode, task_id
    task_id = str(r_arr2["id"])
    task_shortcode = str(r_arr2["shortcode"])

def task_check(v_atoken, v_task_id):
    r3 = requests.get('https://tasks.vto.pe/botapi/tasks/i/done/ok?atoken='+ str(v_atoken) +'&id=' + str(v_task_id))
    try:
        r3_arr = r3.json()
        print('\nРезультат (если ок, то все хорошо) - ' + str(r3_arr['error']) + '\n')
    except:
        print('Some error')

def clear_cookies():
    driver.get('https://google.com')
    sleep(2)
    driver.delete_all_cookies()
    sleep(1)
    print('Cookies cleared... Switching accounts...')

def get_cookie():
    pickle.dump(driver.get_cookies(), open('D:/Program Files (x86)/Programming/Python/Projects/iBot_v.1.0/cookies/' + i_usr + '_cookie', 'wb'))
    print('cookie saved')

def upload_cookie(i_username):
    for cookie in pickle.load(open(f'D:/Program Files (x86)/Programming/Python/Projects/iBot_v.1.0/cookies/{i_username}_cookie', 'rb')):
        driver.add_cookie(cookie)
    print('Cookie loaded')
    sleep(3)  



options = webdriver.ChromeOptions()
options.add_argument('--headless')
options.add_argument('--lang=en')
options.add_argument('user-agent='+str(useragent))
options.add_argument('--window-size=1080,2042')
options.add_argument('--disable-blink-features=AutomationControlled')

if use_proxy == 'y':
    if login != 'n':
        proxy_options = {
            "proxy": {
                "https": f"http://{login}:{password}@{host}:{port}"
            }
        }
    else:
        proxy_options = {
        "proxy": {
                "https": f"http://{host}:{port}"
            }
        }

#45.144.169.59:8000 	r7V139:4a2Tgd
#104.227.98.69:8000 	NCsVyN:YhxeQn
if use_proxy == 'y':
    driver = webdriver.Chrome(executable_path='D:/Program Files (x86)/Programming/Python/Projects/iBot_v.1.0/chromedriver.exe', seleniumwire_options=proxy_options, options=options)
else:
    driver = webdriver.Chrome(executable_path='D:/Program Files (x86)/Programming/Python/Projects/iBot_v.1.0/chromedriver.exe', options=options)

try:
    get_atoken(i_usr, i_id, btoken)
    atoken_1 = atoken
    print(atoken_1)
    get_atoken(i_usr_2, i_id_2, btoken)
    atoken_2 = atoken
    print(atoken_2)
    get_atoken(i_usr_3, i_id_3, btoken)
    atoken_3 = atoken
    print(atoken_3)
    yy = 1
    zz = 0
    xx = 0

    while zz < 3:
        print('Начинаем!')
        if yy == 1:
            main_user = i_usr
            main_password = i_pass
            main_id = i_id
            main_atoken = atoken_1
        if yy == 2:
            main_user = i_usr_2
            main_password = i_pass_2
            main_id = i_id_2
            main_atoken = atoken_2
        if yy == 3:
            main_user = i_usr_3
            main_password = i_pass_3
            main_id = i_id_3
            main_atoken = atoken_3


        driver.get('https://google.com')
        sleep(1)
        try:
            upload_cookie(main_user)
            driver.get('https://instagram.com/')
        except Exception as ex:
            print(ex, 'Cookie not found. Log in...')
            i_login(main_user, main_password)
        sleep(10)

        
        while xx < 5:
            try:
                get_follow_task(main_atoken)
            except Exception as ex:
                print(ex, 'Wait... Ждем')
                sleep(121)
                try:
                    get_follow_task(main_atoken)
                except Exception as ex:
                    print('Wait 2...')
            print('Task id: ' + task_id + '\n Подписываемся на ' + task_shortcode + '\n')
            try:
                follow(task_shortcode)
                sleep(2)
                task_check(main_atoken, task_id)
            except Exception as ex:
                print(ex, 'Ошибка во время подписки на' + task_shortcode)
            sleep(random.randrange(131, 183))
            xx = xx+1
        try:
            clear_cookies()
        except Exception as ex:
            print(ex, 'Cookies не очищены!')
        zz = zz+1
        yy = yy+1
        xx = 0 
    
    # try:
    #     clear_cookies()
    #     upload_cookie(i_usr_2)
    #     driver.get('https://instagtram.com')
    #     sleep(600)
    # except:
    #     print('Uploading cookie fail')
except Exception as ex:
    print(ex, 'Some error... Stopping...')
finally:
    driver.quit()
    print('Quit success')